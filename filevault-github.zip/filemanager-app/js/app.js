/* ═══════════════════════════════════════════
   FileVault — app.js
   ═══════════════════════════════════════════ */

'use strict';

// ─── CONFIG ───────────────────────────────
const CONFIG_KEY = 'filevault_config';
const DATA_KEY   = 'filevault_data';
const SESSION_KEY = 'filevault_session';

// Default password hash (SHA-256 of "filevault123")
const DEFAULT_PASS_HASH = 'b6c2f4c3e1a2e5f9d7b8c9a0e1f2d3c4b5a6e7f8d9c0b1a2e3f4d5c6b7a8e9f0';

const EMOJIS = ['📁','📂','🗂️','📋','📊','📈','📉','🗃️','💾','📱','💻','🔧','⚙️','🔑','🏠','🚗','🎯','💼','🎓','🏋️','🎵','🎬','🌐','🔒','💡','⭐','🔥','💎'];
const COLORS = ['#6c63ff','#3ecfcf','#ff5370','#ffba00','#3ecf8e','#ff9f43','#ee5a24','#0652DD','#9980FA','#fd9644'];

// ─── STATE ────────────────────────────────
let state = {
  data: {
    categories: [],
    version: 1,
    updatedAt: null
  },
  config: {
    passHash: DEFAULT_PASS_HASH,
    driveClientId: '',
    driveApiKey: '',
    ghToken: '',
    ghRepo: ''
  },
  ui: {
    currentCat: null,
    currentSubcat: null,
    selectedEmoji: '📁',
    selectedColor: '#6c63ff',
    currentModal: null
  },
  drive: {
    isConnected: false,
    accessToken: null,
    tokenExpiry: null
  }
};

// ─── INIT ─────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  loadState();
  renderEmojiPicker();
  renderColorPicker();
  checkSession();
  document.getElementById('passwordInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
});

function loadState() {
  try {
    const saved = localStorage.getItem(DATA_KEY);
    if (saved) state.data = JSON.parse(saved);
  } catch(e) {}
  try {
    const cfg = localStorage.getItem(CONFIG_KEY);
    if (cfg) state.config = { ...state.config, ...JSON.parse(cfg) };
  } catch(e) {}
}

function saveState() {
  state.data.updatedAt = new Date().toISOString();
  localStorage.setItem(DATA_KEY, JSON.stringify(state.data));
  localStorage.setItem(CONFIG_KEY, JSON.stringify(state.config));
}

function checkSession() {
  const s = sessionStorage.getItem(SESSION_KEY);
  if (s === 'ok') showApp();
}

// ─── AUTH ─────────────────────────────────
function doLogin() {
  const pass = document.getElementById('passwordInput').value;
  const btn = document.getElementById('loginBtn');
  btn.disabled = true;
  btn.textContent = '...';

  sha256(pass).then(hash => {
    if (hash === state.config.passHash) {
      document.getElementById('loginError').classList.remove('visible');
      sessionStorage.setItem(SESSION_KEY, 'ok');
      showApp();
      syncData(true);
    } else {
      document.getElementById('loginError').classList.add('visible');
      document.getElementById('passwordWrap').style.animation = 'none';
      requestAnimationFrame(() => {
        document.getElementById('passwordWrap').style.animation = 'shake .4s ease';
      });
    }
    btn.disabled = false;
    btn.textContent = 'Intră în aplicație';
  });
}

function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  document.getElementById('appScreen').classList.remove('active');
  document.getElementById('loginScreen').classList.add('active');
  document.getElementById('passwordInput').value = '';
}

function showApp() {
  document.getElementById('loginScreen').classList.remove('active');
  document.getElementById('appScreen').classList.add('active');
  navigate('home');
}

function togglePass() {
  const inp = document.getElementById('passwordInput');
  inp.type = inp.type === 'password' ? 'text' : 'password';
}

// ─── NAVIGATION ───────────────────────────
function navigate(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const el = document.getElementById('page-' + page);
  if (el) el.classList.add('active');

  const navBtns = document.querySelectorAll('.nav-item');
  navBtns.forEach(b => {
    if (b.getAttribute('onclick')?.includes(page)) b.classList.add('active');
  });

  const titles = { home: 'Acasă', categories: 'Categorii', drive: 'Google Drive', settings: 'Setări' };
  document.getElementById('breadcrumb').textContent = titles[page] || page;

  if (page === 'home') renderHome();
  if (page === 'categories') renderCategories();
  if (page === 'drive') initDrivePage();
  if (page === 'settings') loadSettingsForm();

  closeSidebarIfMobile();
}

function closeSidebarIfMobile() {
  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('active');
  }
}

function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('sidebarOverlay');
  sb.classList.toggle('open');
  ov.classList.toggle('active');
}

// ─── HOME ─────────────────────────────────
function renderHome() {
  const cats = state.data.categories;
  const totalSubcats = cats.reduce((a, c) => a + (c.subcategories?.length || 0), 0);
  const totalFiles = cats.reduce((a, c) =>
    a + (c.subcategories || []).reduce((b, s) => b + (s.files?.length || 0), 0), 0);

  document.getElementById('statsRow').innerHTML = `
    <div class="stat-card"><div class="stat-icon">📁</div><div class="stat-num">${cats.length}</div><div class="stat-label">Categorii</div></div>
    <div class="stat-card"><div class="stat-icon">🗂️</div><div class="stat-num">${totalSubcats}</div><div class="stat-label">Subcategorii</div></div>
    <div class="stat-card"><div class="stat-icon">📄</div><div class="stat-num">${totalFiles}</div><div class="stat-label">Fișiere</div></div>
  `;

  const grid = document.getElementById('homeCategories');
  grid.innerHTML = cats.length ? cats.slice(0, 6).map(c => categoryCardHTML(c, 'home')).join('') : `
    <div class="files-empty" style="grid-column:1/-1">
      <div class="empty-icon">📂</div>
      <p>Nicio categorie încă.<br>Mergi la <strong>Categorii</strong> pentru a crea una.</p>
    </div>
  `;
  grid.querySelectorAll('.category-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.closest('.card-actions')) return;
      navigate('categories');
      setTimeout(() => openCategory(card.dataset.id), 50);
    });
  });
}

// ─── CATEGORIES ───────────────────────────
function renderCategories() {
  document.getElementById('subcatView').classList.add('hidden');
  document.getElementById('filesView').classList.add('hidden');
  document.getElementById('catMainView').classList.remove('hidden');

  const grid = document.getElementById('categoriesGrid');
  const cats = state.data.categories;
  grid.innerHTML = cats.length ? cats.map(c => categoryCardHTML(c, 'main')).join('') : `
    <div class="files-empty" style="grid-column:1/-1">
      <div class="empty-icon">📁</div>
      <p>Nicio categorie. Creează una cu butonul de mai sus!</p>
    </div>
  `;
  grid.querySelectorAll('.category-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.closest('.card-actions')) return;
      openCategory(card.dataset.id);
    });
  });
}

function categoryCardHTML(cat, ctx) {
  const subcatCount = cat.subcategories?.length || 0;
  return `
    <div class="category-card" data-id="${cat.id}" style="--card-color:${cat.color}">
      <span class="card-emoji">${cat.emoji}</span>
      <div class="card-name">${escHtml(cat.name)}</div>
      <div class="card-meta">${subcatCount} subcategor${subcatCount === 1 ? 'ie' : 'ii'}</div>
      ${ctx === 'main' ? `
      <div class="card-actions">
        <button class="card-action-btn" onclick="event.stopPropagation();deleteCategory('${cat.id}')" title="Șterge">✕</button>
      </div>` : ''}
    </div>
  `;
}

function openCategory(catId) {
  const cat = state.data.categories.find(c => c.id === catId);
  if (!cat) return;
  state.ui.currentCat = catId;

  document.getElementById('catMainView').classList.add('hidden');
  document.getElementById('subcatView').classList.remove('hidden');
  document.getElementById('filesView').classList.add('hidden');
  document.getElementById('subcatTitle').textContent = cat.emoji + ' ' + cat.name;
  document.getElementById('breadcrumb').textContent = cat.name;

  renderSubcategories(cat);
}

function renderSubcategories(cat) {
  const grid = document.getElementById('subcatGrid');
  const subs = cat.subcategories || [];
  grid.innerHTML = subs.length ? subs.map(s => `
    <div class="category-card subcat-card" data-id="${s.id}" style="--card-color:${cat.color}">
      <span class="card-emoji">🗂️</span>
      <div class="card-name">${escHtml(s.name)}</div>
      <div class="card-meta">${s.files?.length || 0} fișier${(s.files?.length || 0) === 1 ? '' : 'e'}</div>
      <div class="card-actions">
        <button class="card-action-btn" onclick="event.stopPropagation();deleteSubcategory('${s.id}')" title="Șterge">✕</button>
      </div>
    </div>
  `).join('') : `
    <div class="files-empty" style="grid-column:1/-1">
      <div class="empty-icon">🗂️</div>
      <p>Nicio subcategorie. Adaugă una!</p>
    </div>
  `;

  grid.querySelectorAll('.subcat-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.closest('.card-actions')) return;
      openSubcategory(card.dataset.id);
    });
  });
}

function openSubcategory(subcatId) {
  const cat = state.data.categories.find(c => c.id === state.ui.currentCat);
  if (!cat) return;
  const sub = (cat.subcategories || []).find(s => s.id === subcatId);
  if (!sub) return;

  state.ui.currentSubcat = subcatId;

  document.getElementById('subcatView').classList.add('hidden');
  document.getElementById('filesView').classList.remove('hidden');
  document.getElementById('filesTitle').textContent = '🗂️ ' + sub.name;
  document.getElementById('breadcrumb').textContent = cat.name + ' › ' + sub.name;

  renderFiles(sub);
}

function renderFiles(sub) {
  const list = document.getElementById('filesList');
  const files = sub.files || [];
  const icons = { pdf:'📄', doc:'📝', img:'🖼️', video:'🎬', zip:'📦', other:'📎' };

  list.innerHTML = files.length ? files.map(f => `
    <a class="file-item" href="${escHtml(f.url)}" target="_blank" rel="noopener">
      <span class="file-icon">${icons[f.type] || '📎'}</span>
      <div class="file-info">
        <div class="file-name">${escHtml(f.name)}</div>
        <div class="file-meta">${f.addedAt ? new Date(f.addedAt).toLocaleDateString('ro-RO') : ''}</div>
      </div>
      <button class="file-del" onclick="event.preventDefault();event.stopPropagation();deleteFile('${f.id}')">✕</button>
    </a>
  `).join('') : `
    <div class="files-empty">
      <div class="empty-icon">📄</div>
      <p>Niciun fișier. Adaugă un link Google Drive sau uploadează direct.</p>
    </div>
  `;
}

function closeSubcat() {
  state.ui.currentCat = null;
  state.ui.currentSubcat = null;
  document.getElementById('subcatView').classList.add('hidden');
  document.getElementById('catMainView').classList.remove('hidden');
  document.getElementById('breadcrumb').textContent = 'Categorii';
  renderCategories();
}

function closeFiles() {
  state.ui.currentSubcat = null;
  document.getElementById('filesView').classList.add('hidden');
  document.getElementById('subcatView').classList.remove('hidden');
  const cat = state.data.categories.find(c => c.id === state.ui.currentCat);
  if (cat) {
    document.getElementById('breadcrumb').textContent = cat.name;
    renderSubcategories(cat);
  }
}

// ─── ADD ITEMS ────────────────────────────
function addCategory() {
  const name = document.getElementById('newCatName').value.trim();
  const emoji = document.getElementById('newCatEmoji').value.trim() || state.ui.selectedEmoji;
  const color = state.ui.selectedColor;
  if (!name) { showToast('Introdu un nume!', 'error'); return; }

  const cat = { id: uid(), name, emoji, color, subcategories: [], createdAt: new Date().toISOString() };
  state.data.categories.push(cat);
  saveState();
  closeModal();
  renderCategories();
  autoSync();
  showToast('Categorie creată ✓', 'success');
}

function addSubcategory() {
  const name = document.getElementById('newSubcatName').value.trim();
  const desc = document.getElementById('newSubcatDesc').value.trim();
  if (!name) { showToast('Introdu un nume!', 'error'); return; }
  const cat = state.data.categories.find(c => c.id === state.ui.currentCat);
  if (!cat) return;

  const sub = { id: uid(), name, desc, files: [], createdAt: new Date().toISOString() };
  if (!cat.subcategories) cat.subcategories = [];
  cat.subcategories.push(sub);
  saveState();
  closeModal();
  renderSubcategories(cat);
  autoSync();
  showToast('Subcategorie creată ✓', 'success');
}

function addFileLink() {
  const name = document.getElementById('newFileName').value.trim();
  const url  = document.getElementById('newFileUrl').value.trim();
  const type = document.getElementById('newFileType').value;
  if (!name || !url) { showToast('Completează toate câmpurile!', 'error'); return; }

  const cat = state.data.categories.find(c => c.id === state.ui.currentCat);
  const sub = (cat?.subcategories || []).find(s => s.id === state.ui.currentSubcat);
  if (!sub) return;

  const file = { id: uid(), name, url, type, addedAt: new Date().toISOString() };
  if (!sub.files) sub.files = [];
  sub.files.push(file);
  saveState();
  closeModal();
  renderFiles(sub);
  autoSync();
  showToast('Fișier adăugat ✓', 'success');
}

// ─── DELETE ───────────────────────────────
function deleteCategory(id) {
  if (!confirm('Ștergi categoria și tot conținutul ei?')) return;
  state.data.categories = state.data.categories.filter(c => c.id !== id);
  saveState();
  renderCategories();
  autoSync();
  showToast('Categorie ștearsă', 'error');
}

function deleteSubcategory(id) {
  if (!confirm('Ștergi subcategoria și fișierele ei?')) return;
  const cat = state.data.categories.find(c => c.id === state.ui.currentCat);
  if (!cat) return;
  cat.subcategories = cat.subcategories.filter(s => s.id !== id);
  saveState();
  renderSubcategories(cat);
  autoSync();
  showToast('Subcategorie ștearsă', 'error');
}

function deleteFile(id) {
  if (!confirm('Ștergi fișierul din listă?')) return;
  const cat = state.data.categories.find(c => c.id === state.ui.currentCat);
  const sub = (cat?.subcategories || []).find(s => s.id === state.ui.currentSubcat);
  if (!sub) return;
  sub.files = sub.files.filter(f => f.id !== id);
  saveState();
  renderFiles(sub);
  autoSync();
  showToast('Fișier șters', 'error');
}

// ─── MODALS ───────────────────────────────
function openModal(name) {
  closeModal();
  document.getElementById('modalOverlay').classList.add('active');
  const m = document.getElementById('modal-' + name);
  if (m) {
    m.classList.add('active');
    state.ui.currentModal = name;
    setTimeout(() => m.querySelector('input')?.focus(), 100);
  }
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('active');
  document.querySelectorAll('.modal.active').forEach(m => m.classList.remove('active'));
  state.ui.currentModal = null;
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

// ─── EMOJI / COLOR PICKERS ────────────────
function renderEmojiPicker() {
  const wrap = document.getElementById('emojiPicker');
  wrap.innerHTML = EMOJIS.map(e => `<div class="emoji-opt ${e === state.ui.selectedEmoji ? 'selected' : ''}" onclick="selectEmoji('${e}')">${e}</div>`).join('');
}

function selectEmoji(e) {
  state.ui.selectedEmoji = e;
  document.getElementById('newCatEmoji').value = e;
  document.querySelectorAll('.emoji-opt').forEach(el => el.classList.toggle('selected', el.textContent === e));
}

function renderColorPicker() {
  const wrap = document.getElementById('colorPicker');
  wrap.innerHTML = COLORS.map(c => `<div class="color-opt ${c === state.ui.selectedColor ? 'selected' : ''}" style="background:${c}" onclick="selectColor('${c}')"></div>`).join('');
}

function selectColor(c) {
  state.ui.selectedColor = c;
  document.querySelectorAll('.color-opt').forEach(el => el.classList.toggle('selected', el.style.background === c || getComputedStyle(el).backgroundColor === hexToRgb(c)));
}

function hexToRgb(hex) {
  const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
  return `rgb(${r}, ${g}, ${b})`;
}

// ─── SETTINGS ────────────────────────────
function loadSettingsForm() {
  document.getElementById('driveClientId').value = state.config.driveClientId || '';
  document.getElementById('driveApiKey').value = state.config.driveApiKey || '';
  document.getElementById('ghToken').value = state.config.ghToken || '';
  document.getElementById('ghRepo').value = state.config.ghRepo || '';
}

function saveDriveConfig() {
  state.config.driveClientId = document.getElementById('driveClientId').value.trim();
  state.config.driveApiKey = document.getElementById('driveApiKey').value.trim();
  saveState();
  showToast('Configurare Drive salvată ✓', 'success');
}

function saveGithubConfig() {
  state.config.ghToken = document.getElementById('ghToken').value.trim();
  state.config.ghRepo = document.getElementById('ghRepo').value.trim();
  saveState();
  showToast('Configurare GitHub salvată ✓', 'success');
}

function changePassword() {
  const p1 = document.getElementById('newPass1').value;
  const p2 = document.getElementById('newPass2').value;
  if (!p1 || p1.length < 6) { showToast('Parola trebuie să aibă minim 6 caractere!', 'error'); return; }
  if (p1 !== p2) { showToast('Parolele nu coincid!', 'error'); return; }
  sha256(p1).then(hash => {
    state.config.passHash = hash;
    saveState();
    autoSync();
    showToast('Parola a fost schimbată ✓', 'success');
    document.getElementById('newPass1').value = '';
    document.getElementById('newPass2').value = '';
  });
}

function resetLocalData() {
  if (!confirm('Resetezi toate datele locale? Datele din GitHub rămân.')) return;
  localStorage.removeItem(DATA_KEY);
  state.data = { categories: [], version: 1, updatedAt: null };
  showToast('Date locale resetate', 'error');
  renderHome();
}

// ─── GITHUB SYNC ──────────────────────────
async function syncData(silent = false) {
  const btn = document.getElementById('syncBtn');
  btn.classList.add('spinning');

  const { ghToken, ghRepo } = state.config;

  try {
    if (ghToken && ghRepo) {
      // Try to fetch latest data from GitHub
      const [owner, repo] = ghRepo.split('/');
      const url = `https://api.github.com/repos/${owner}/${repo}/contents/data.json`;

      const res = await fetch(url, {
        headers: {
          'Authorization': `token ${ghToken}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      });

      if (res.ok) {
        const json = await res.json();
        const remote = JSON.parse(atob(json.content));
        // Merge: take whichever is newer
        const remoteDate = new Date(remote.updatedAt || 0);
        const localDate  = new Date(state.data.updatedAt || 0);

        if (remoteDate > localDate) {
          state.data = remote;
          saveState();
          if (!silent) showToast('Date actualizate din GitHub ✓', 'success');
          navigate(document.querySelector('.page.active')?.id?.replace('page-','') || 'home');
        } else {
          // Push local to GitHub
          await pushToGitHub(json.sha);
          if (!silent) showToast('Date sincronizate pe GitHub ✓', 'success');
        }
      } else if (res.status === 404) {
        // File doesn't exist yet — create it
        await pushToGitHub(null);
        if (!silent) showToast('Fișier creat pe GitHub ✓', 'success');
      }
    } else {
      if (!silent) showToast('Configurează GitHub în Setări pentru sincronizare', 'error');
    }
  } catch(e) {
    if (!silent) showToast('Eroare sincronizare: ' + e.message, 'error');
  }

  btn.classList.remove('spinning');
}

async function pushToGitHub(sha) {
  const { ghToken, ghRepo } = state.config;
  const [owner, repo] = ghRepo.split('/');

  // Exclude sensitive keys before pushing
  const pushData = {
    ...state.data,
    _passHash: state.config.passHash
  };

  const content = btoa(unescape(encodeURIComponent(JSON.stringify(pushData, null, 2))));
  const body = {
    message: 'FileVault sync ' + new Date().toISOString(),
    content,
    ...(sha ? { sha } : {})
  };

  const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/data.json`, {
    method: 'PUT',
    headers: {
      'Authorization': `token ${ghToken}`,
      'Content-Type': 'application/json',
      'Accept': 'application/vnd.github.v3+json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) throw new Error('GitHub push failed: ' + res.status);
}

function autoSync() {
  if (state.config.ghToken && state.config.ghRepo) {
    clearTimeout(window._syncTimer);
    window._syncTimer = setTimeout(() => syncData(true), 2000);
  }
}

// ─── GOOGLE DRIVE ─────────────────────────
function initDrivePage() {
  if (state.drive.isConnected) {
    document.getElementById('driveStatus').classList.add('hidden');
    document.getElementById('driveFiles').classList.remove('hidden');
    loadDriveFiles();
  }
}

function initDriveAuth() {
  const clientId = state.config.driveClientId;
  if (!clientId) {
    showToast('Configurează Client ID în Setări → Google Drive', 'error');
    navigate('settings');
    return;
  }

  const scope = 'https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/drive.readonly';
  const redirectUri = encodeURIComponent(window.location.origin + window.location.pathname);
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=token&scope=${encodeURIComponent(scope)}&prompt=select_account`;

  const popup = window.open(authUrl, 'driveAuth', 'width=500,height=600');

  const checkPopup = setInterval(() => {
    try {
      if (!popup || popup.closed) {
        clearInterval(checkPopup);
        return;
      }
      const hash = popup.location.hash;
      if (hash) {
        const params = new URLSearchParams(hash.substring(1));
        const token = params.get('access_token');
        const expiresIn = params.get('expires_in');
        if (token) {
          state.drive.accessToken = token;
          state.drive.tokenExpiry = Date.now() + (parseInt(expiresIn) * 1000);
          state.drive.isConnected = true;
          popup.close();
          clearInterval(checkPopup);
          document.getElementById('driveStatus').classList.add('hidden');
          document.getElementById('driveFiles').classList.remove('hidden');
          loadDriveFiles();
          showToast('Conectat la Google Drive ✓', 'success');
        }
      }
    } catch(e) {}
  }, 500);
}

async function loadDriveFiles() {
  if (!state.drive.accessToken) return;
  const list = document.getElementById('driveFilesList');
  list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text2)">Se încarcă...</div>';

  try {
    const res = await fetch('https://www.googleapis.com/drive/v3/files?pageSize=50&fields=files(id,name,mimeType,size,modifiedTime,webViewLink)', {
      headers: { 'Authorization': 'Bearer ' + state.drive.accessToken }
    });
    const data = await res.json();

    if (data.error) {
      list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--danger)">Eroare: ' + data.error.message + '</div>';
      return;
    }

    const files = data.files || [];
    const icons = {
      'application/pdf': '📄',
      'image/': '🖼️',
      'video/': '🎬',
      'audio/': '🎵',
      'application/vnd.google-apps.folder': '📁',
      'application/zip': '📦',
      'default': '📎'
    };

    function getIcon(mime) {
      for (const k in icons) { if (mime.startsWith(k)) return icons[k]; }
      return icons.default;
    }

    list.innerHTML = files.length ? files.map(f => `
      <div class="file-item">
        <span class="file-icon">${getIcon(f.mimeType)}</span>
        <div class="file-info">
          <div class="file-name">${escHtml(f.name)}</div>
          <div class="file-meta">${f.modifiedTime ? new Date(f.modifiedTime).toLocaleDateString('ro-RO') : ''}</div>
        </div>
        <div style="display:flex;gap:6px">
          <button class="btn-sm btn-outline" onclick="copyDriveLink('${escHtml(f.webViewLink || '')}')">📋 Copiază link</button>
          <a class="btn-sm btn-primary" href="${escHtml(f.webViewLink || '#')}" target="_blank" rel="noopener">Deschide</a>
        </div>
      </div>
    `).join('') : '<div class="files-empty"><div class="empty-icon">☁️</div><p>Drive-ul este gol.</p></div>';
  } catch(e) {
    list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--danger)">Eroare rețea: ' + e.message + '</div>';
  }
}

function uploadToDrive() {
  document.getElementById('driveUploadInput').click();
}

async function handleDriveUpload(event) {
  const files = event.target.files;
  if (!files.length || !state.drive.accessToken) return;

  showToast('Se uploadează ' + files.length + ' fișier(e)...', '');

  for (const file of files) {
    try {
      const metadata = { name: file.name };
      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', file);

      const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + state.drive.accessToken },
        body: form
      });

      if (!res.ok) throw new Error('Upload failed');
      showToast(file.name + ' uploadat ✓', 'success');
    } catch(e) {
      showToast('Eroare upload ' + file.name, 'error');
    }
  }

  event.target.value = '';
  loadDriveFiles();
}

function copyDriveLink(url) {
  if (!url) return;
  navigator.clipboard.writeText(url).then(() => showToast('Link copiat ✓', 'success'));
}

function openDrivePicker() {
  if (state.drive.isConnected) {
    uploadToDrive();
  } else {
    showToast('Conectează-te mai întâi la Google Drive', 'error');
    navigate('drive');
  }
}

// ─── UTILS ────────────────────────────────
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}

async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// CSS shake animation for wrong password
const styleEl = document.createElement('style');
styleEl.textContent = `@keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-8px)}40%,80%{transform:translateX(8px)}}`;
document.head.appendChild(styleEl);
