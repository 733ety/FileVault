# 🏠 FileVault

Aplicație mobilă PWA + APK Android pentru gestionarea fișierelor cu Google Drive.

## ✅ Funcționalități

- 🔐 **Parolă la intrare** (SHA-256 hash, implicită: `filevault123`)
- 📁 **Categorii** cu emoji și culori personalizate
- 🗂️ **Subcategorii** în fiecare categorie
- 📄 **Fișiere/linkuri** cu deschidere directă
- ☁️ **Google Drive** — upload direct și link-uri
- 🔄 **Sincronizare GitHub** — toți utilizatorii văd aceleași date
- 📱 **PWA** — instalabil pe iOS și Android
- 📦 **APK Android** — build automat prin GitHub Actions

---

## 🚀 Instalare rapidă (5 pași)

### 1. Creează repository pe GitHub

```bash
# Mergi pe github.com → New Repository
# Nume: filevault (sau orice altceva)
# Vizibilitate: Public (necesar pentru GitHub Pages)
```

### 2. Încarcă fișierele

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/USERNAME/filevault.git
git push -u origin main
```

### 3. Activează GitHub Pages

- Mergi în repo → **Settings** → **Pages**
- Source: **GitHub Actions**
- Salvează

Aplicația va fi live la: `https://USERNAME.github.io/filevault`

### 4. (Opțional) Build APK Android

Push un tag pentru a declanșa build-ul APK:

```bash
git tag v1.0.0
git push origin v1.0.0
```

APK-ul apare în **Releases** pe GitHub. Descarcă și instalează pe Android.

### 5. Configurează sincronizarea

În aplicație → **Setări → Sincronizare GitHub**:

1. Creează un **Personal Access Token** pe GitHub:
   - github.com → Settings → Developer Settings → Personal access tokens → Fine-grained tokens
   - Repository: filevault
   - Permissions: `Contents` → Read & Write
2. Introdu token-ul și `USERNAME/filevault` în setări
3. Apasă **Salvează** — datele se vor sincroniza automat

---

## 📱 Instalare pe telefon

### iOS (iPhone/iPad)
1. Deschide `https://USERNAME.github.io/filevault` în **Safari**
2. Apasă iconița **Share** (pătrat cu săgeată)
3. **Add to Home Screen**
4. Aplicația apare ca o iconiță nativă

### Android (PWA)
1. Deschide URL-ul în **Chrome**
2. Apare bannerul "Adaugă la ecranul principal" — acceptă
3. SAU: meniu Chrome → **Add to Home Screen**

### Android (APK)
1. Descarcă `FileVault-debug.apk` din **Releases**
2. Pe telefon: **Setări → Securitate → Instalare din surse necunoscute**
3. Deschide APK-ul descărcat

---

## ☁️ Configurare Google Drive

### Obținere credențiale (gratuit)

1. Mergi la [console.cloud.google.com](https://console.cloud.google.com)
2. Creează un proiect nou
3. **APIs & Services → Enable APIs** → activează `Google Drive API`
4. **APIs & Services → Credentials → Create Credentials → OAuth 2.0 Client ID**
   - Application type: **Web application**
   - Authorized JavaScript origins: `https://USERNAME.github.io`
   - Authorized redirect URIs: `https://USERNAME.github.io/filevault/`
5. Copiază **Client ID**
6. Creează și un **API Key** (Credentials → Create → API Key)

7. În aplicație → **Setări → Google Drive API** → introdu Client ID și API Key

---

## 🔐 Schimbare parolă

**Metoda 1** — Din aplicație:
- Setări → Securitate → Schimbă parola → Salvează
- Se sincronizează automat cu toți utilizatorii

**Metoda 2** — Manual în cod:
```javascript
// Generează hash SHA-256 al parolei dorite pe: https://emn178.github.io/online-tools/sha256.html
// Înlocuiește DEFAULT_PASS_HASH în js/app.js
```

---

## 📂 Structura fișierelor

```
filevault/
├── index.html              # Aplicația principală
├── css/style.css           # Stiluri
├── js/app.js               # Logica aplicației
├── sw.js                   # Service Worker (offline)
├── manifest.json           # PWA manifest
├── capacitor.config.js     # Config Capacitor (APK)
├── package.json            # Dependencies
├── icons/                  # Iconițe aplicație
│   ├── icon-192.png
│   └── icon-512.png
└── .github/workflows/
    ├── deploy-pages.yml    # Deploy automat PWA
    └── build-apk.yml       # Build APK Android
```

---

## 🔄 Cum funcționează sincronizarea

```
Utilizator A modifică ceva
    ↓
Se salvează local (localStorage)
    ↓ (după 2 secunde)
Se trimite pe GitHub (data.json în repo)
    ↓
Utilizator B apasă 🔄 Sincronizare
    ↓
Descarcă data.json din GitHub
    ↓
Vede modificările lui A
```

Sincronizarea este **manuală** (butonul 🔄) sau **automată** la fiecare modificare.

---

## ⚠️ Limitări cunoscute

| Aspect | Detaliu |
|--------|---------|
| iOS APK | Nu există — Apple nu permite distribuție în afara App Store |
| Parolă | Securitate de bază — nu folosiți date ultra-sensibile |
| GitHub sync | Necesită token PAT (expiră după 1 an) |
| Drive upload | Necesită Google Cloud Console (gratuit) |

---

## 💡 Sfaturi

- **Backup date**: Repo-ul GitHub ÎS datele tale — sunt safe
- **Parola default**: `filevault123` — schimb-o imediat din Setări
- **iOS**: Folosește EXCLUSIV Safari pentru instalare PWA
- **Offline**: Aplicația funcționează și fără internet după prima accesare
